<p align="center">
  <img src="resources/RiZoeLX.png" alt="RiZoeLXSpam Logo">
</p>
<h6 align="center">
  <b>• SᴘᴀᴍX Bʏ RɪZᴏᴇLX •</b>
</h6>

----

<b> SpamX Is A Pyrogram Based Spam Bots For Telegram With Many Features </b>

![github card](https://github-readme-stats.vercel.app/api/pin/?username=RiZoeLX&repo=SpamX&theme=lite)

![Repo Size](https://img.shields.io/github/repo-size/RiZoeLX/SpamX?&style=social&logo=github)
![Branch](https://img.shields.io/badge/Branch-main-white?&style=social&logo=github)
![Python](https://img.shields.io/badge/Python-v3.10-white?style=social&logo=python)
![GitHub language count](https://img.shields.io/github/languages/count/RiZoeLX/SpamX?&style=social&logo=hyper)

[![Telegram Group](https://img.shields.io/badge/Telegram-Group-white?&style=social&logo=telegram)](https://t.me/DNHxHELL)
[![Telegram Channel](https://img.shields.io/badge/Telegram-Channel-white?&style=social&logo=telegram)](https://t.me/RiZoelX)

 - Requirements
   - [![PyPI - pyrogram](https://img.shields.io/badge/pypi-pyrogram-informational)](https://pypi.org/project/pyrogram)  
   - [![PyPI - pyRiZoeLX](https://img.shields.io/badge/pypi-pyRiZoeLX-informational)](https://pypi.org/project/pyRiZoeLX) 

<b> Give a star ⭐</b>

----
<h4>Youtube Tutorials 📺</h4>

- [![YouTube Video](https://img.shields.io/youtube/views/GW_ZNdRrFtg?label=Tutorial++Heroku++&style=social)](https://youtu.be/GW_ZNdRrFtg)
- [![YouTube Video](https://img.shields.io/youtube/views/6XIjTbumJYY?label=Tutorial++Mogenius++&style=social)](https://youtu.be/6XIjTbumJYY)
- [![YouTube Video](https://img.shields.io/youtube/views/sYgy4_8i7c8?label=Tutorial++Google++Colab++&style=social)](https://youtu.be/sYgy4_8i7c8)
- [![YouTube Video](https://img.shields.io/youtube/views/yC9z3kYKIgU?label=Tutorial++VPS++&style=social)](https://youtu.be/yC9z3kYKIgU)
- [![YouTube Video](https://img.shields.io/youtube/views/ePpMvL6kdvI?label=Tutorial++VPS++Mobile++&style=social)](https://youtu.be/ePpMvL6kdvI)

----

<h3 align="center">Deployment</h3>

  - Heroku: [Click Here](https://github.com/RiZoeLX/SpamX/blob/main/resources/heroku.md)
  - Mogenius: [Click Here](https://youtu.be/6XIjTbumJYY)
  - Google Colab: [Click Here](https://youtu.be/sYgy4_8i7c8)
  - VPS/Local hosting: [Click here](https://github.com/RiZoeLX/SpamX/blob/main/resources/local.md)
  - Termux: [Click Here](https://github.com/RiZoeLX/SpamX/blob/main/resources/termux.md) `Some errors!`

----

<h3 align="center">String session</h3>

> You can generate multiple sessions!

<h4>Repl</h4>

  * Open Repl Link.
  * Click on Green Play Button.
  * Wait for requirements to finish.
  * next Steps:
    * Fill API_ID, API_HASH (It'll use same api id and hash to generate sessions, so use fresh).
    * Enter the no. of accounts on you want to generate string sessions.
    * Enter Username of user to whom you want to forward all seasons or press enter.
    * Phone number (with country code).
    * Paste the OTP received on Telegram.
    * If You have Enabled 2-Step Verification then fill your password.


  * [![Replit](https://img.shields.io/badge/SpamX-Run%20On%20ReplIT-black?style=for-the-badge&logo=replit)](https://replit.com/@RiZoeL/SpamX-Sessions?v=1)


<h4>Terminal</4>
<br>

  * Open terminal

   ```python
pkg install python wget -y && pip install pyrogram  && pip install tgcrypto&& wget https://raw.githubusercontent.com/RiZoeLX/SpamX/main/multisess.py && python3 multisess.py
   ```
  * Paste ☝️ This code

  * next Steps:
     * Fill API_ID, API_HASH (It'll use same api id and hash to generate sessions, so use fresh).
     * Enter the no. of accounts on you want to generate string sessions.
     * Enter Username of user to whom you want to forward all seasons or press enter.
     * Phone number (with country code).
     * Paste the OTP received on Telegram.
     * If You have Enabled 2-Step Verification then fill your password.

<h4> License </h4>

[![License](https://www.gnu.org/graphics/gplv3-or-later.png)](LICENSE)   
SpamX is licensed under [GNU Affero General Public License](https://www.gnu.org/licenses/gplv3-or-later.pngl) v3 or later.

<h3>Credits</h3>

  - <b> [RiZoeL](https://github.com/MrRizoel) : Dev/creator of SpamX </b> 
  - <b> [Pyrogram](https://github.com/pyrogram/pyrogram) : Python Library used in SpamX
