<h2> Heroku Deployment </h2>

> The easy way to host this bot, deploy to Heroku 
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/RiZoeLX/SpamX)

<h3>Tutorial video</h3>
<br>
× <i> Check below icon/image </i> <br>

<p><a href="https://youtu.be/GW_ZNdRrFtg"><img src="https://telegra.ph//file/022296de189ff726a4f1e.jpg" width="200""/></a></p>
